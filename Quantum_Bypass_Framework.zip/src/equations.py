"""Core mathematical models for the Quantum Bypass Framework"""
import numpy as np
from .utils import delta_negative, delta_positive, delta_zero, delta_infinity

def entanglement_model(x: float, y: float, psi: float, beta: float, lam: float, theta: float, Q: float) -> float:
    """Higher‑dimensional entanglement simulation (simplified float version)"""
    denom = theta * x**2 + y**2 + 1e-9
    return beta * np.sin(psi * x) * np.exp(lam * y) / denom

def fractal_recursion_overlay(x: float, q: float, alpha: float, theta: float, gamma: float) -> float:
    """Single‑step fractal recursion approximation"""
    return alpha * np.exp(-theta * q * x**2) + gamma * np.exp(-theta * q * (x*0.7)**2)

def chaotic_noise_filter(x: float, beta: float, eta: float, Q: float, lam: float, theta: float, mu: float) -> float:
    """Chaotic noise reduction function"""
    denom = theta * x**2 + Q**2 + mu
    return np.log(beta * abs(x) + eta * Q + 1e-9) * np.exp(lam * x) / denom

def ethical_overlay(x: float, t: float, alpha: float, beta: float, phi: float, omega: float) -> float:
    """Dynamic ethical oscillation"""
    return alpha * np.sin(phi * x) + beta * np.cos(omega * t)

def genetic_adaptation_equation(x: float, y: float, Q: float, b1: float, b2: float,
                                eta: float, alpha: float, beta: float, gamma: float,
                                theta: float, lam: float) -> float:
    """Adaptation equation ported from earlier framework"""
    log_term = b2 * np.log(b1 + eta * Q * abs(x) + 1e-9)
    exp_term = np.exp(lam * x)
    inner = 1 + alpha * delta_negative(x) + beta * delta_positive(x) + gamma * np.exp(-theta * Q * x**2)
    return log_term * exp_term * inner