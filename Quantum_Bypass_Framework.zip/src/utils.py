"""Utility delta functions and helpers"""

def delta_negative(x: float) -> int:
    """Discrete delta function: 1 if x < 0 else 0"""
    return 1 if x < 0 else 0

def delta_positive(x: float) -> int:
    """Discrete delta function: 1 if x > 0 else 0"""
    return 1 if x > 0 else 0

def delta_zero(x: float, eps: float = 1e-9) -> int:
    """Kronecker-like delta around zero"""
    return 1 if abs(x) < eps else 0

def delta_infinity(x: float, thresh: float = 1e6) -> int:
    """Treats very large |x| as 'infinity' for practical purposes"""
    return 1 if abs(x) > thresh else 0