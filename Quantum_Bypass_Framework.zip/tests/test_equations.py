import numpy as np
from src.equations import genetic_adaptation_equation, entanglement_model

def test_genetic_adaptation_positive():
    val = genetic_adaptation_equation(1.0, 2.0, 0.5, 0.4, 1.6, 0.01, 0.3, 0.4, 0.6, 0.1, 0.01)
    assert val > 0

def test_entanglement_model_stability():
    val = entanglement_model(1.0, 1.0, 0.8, 1.2, 0.01, 0.1, 0.7)
    assert np.isfinite(val)